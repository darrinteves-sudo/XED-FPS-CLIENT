# XED FPS Client — source project

Target: Minecraft Java 1.21.11 / Fabric / Java 21.

## What this first build does
- Adds one configurable keybind (default **O**) to switch Minecraft's particle setting to **Minimal**.
- Press O again to restore the particle setting that was active before the toggle.
- Uses Fabric API client tick + keybinding hooks; it does not replace Sodium, MobileGlues, or any renderer.
- It does not alter combat logic, packet behavior, server state, or other optimization mods.

## Important limits
This is a small first version, not a 500-FPS generator. It can reduce particle workload in busy fights, but it cannot guarantee a particular FPS. It has not been compiled or tested inside your exact Zalith + MobileGlues installation yet. Keep a backup of your instance and test with your existing mods before relying on it.

## Build on GitHub (phone-friendly route)
1. Create a new empty GitHub repository.
2. Extract this ZIP and upload the **contents** of this folder to the repository root (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Run **Build XED FPS Client**, or push the files to the `main` branch.
5. Open the completed workflow run and download the artifact named `XED-FPS-Client-1.21.11`.
6. Extract the artifact and copy the resulting `.jar` into this Minecraft instance's `.minecraft/mods` folder.
7. Start with a backup. If the game crashes, remove `xed-fps-client` first.

## In game
Open **Options → Controls → Key Binds → XED FPS Client** to change the key. Default: **O**. On mobile, bind it to a key/button your Zalith control layout can send.

## Build configuration
Uses Fabric Loom 1.14-SNAPSHOT, Yarn 1.21.11+build.6, Fabric Loader 0.18.1 and Fabric API 0.141.1+1.21.11. See the official Fabric docs for Loom/build setup:
https://docs.fabricmc.net/develop/loom/
