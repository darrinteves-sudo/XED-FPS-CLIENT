# XED FPS Client — corrected source project

Target: Minecraft Java 1.21.11 / Fabric / Java 21.

## Current feature
- Press **O** to switch Minecraft's particle setting to **Minimal**.
- Press **O** again to restore the particle setting that was active before the toggle.
- The key is listed under **Options → Controls → Key Binds → XED FPS Client**.
- This is a client-side settings toggle. It does not replace Sodium or MobileGlues, alter combat logic, or guarantee a particular FPS.

## Compatibility and limits
This source corrects the Minecraft 1.21.11 keybinding category type: custom key categories use `KeyBinding.Category` and an `Identifier`, rather than the older string argument. The category translation key is `key.category.xedfps.performance`.

The project has not been compiled or tested inside the exact Zalith + MobileGlues installation. Back up the Minecraft instance before testing. If the game crashes after installing the JAR, remove `xedfps` from the mods folder.

## Build
The included GitHub Actions workflow uses Java 21 and Gradle 9.2.0. Upload the **contents** of this folder to a repository root, then run the **Build XED FPS Client** workflow and download its artifact.

This is a small particle-toggle helper, not a 500-FPS generator. It may reduce particle load during busy moments, but actual performance depends on the device, renderer, settings, world and other installed mods.
