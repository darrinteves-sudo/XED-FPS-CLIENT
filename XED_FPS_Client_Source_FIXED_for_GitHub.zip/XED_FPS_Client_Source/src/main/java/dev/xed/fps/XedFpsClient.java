package dev.xed.fps;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.ParticlesMode;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class XedFpsClient implements ClientModInitializer {
    private static final KeyBinding.Category XED_CATEGORY =
        KeyBinding.Category.create(Identifier.of("xedfps", "performance"));

    private static KeyBinding toggleParticlesKey;
    private static ParticlesMode previousParticles = ParticlesMode.ALL;
    private static boolean reduced = false;

    @Override
    public void onInitializeClient() {
        toggleParticlesKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding(
                "key.xedfps.toggle_particles",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                XED_CATEGORY
            )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleParticlesKey.wasPressed()) {
                if (client.player == null) continue;

                if (!reduced) {
                    previousParticles = client.options.getParticles().getValue();
                    client.options.getParticles().setValue(ParticlesMode.MINIMAL);
                    reduced = true;
                    client.player.sendMessage(
                        Text.literal("XED FPS: Reduced particles ON"),
                        true
                    );
                } else {
                    client.options.getParticles().setValue(previousParticles);
                    reduced = false;
                    client.player.sendMessage(
                        Text.literal("XED FPS: Reduced particles OFF"),
                        true
                    );
                }
            }
        });
    }
}
